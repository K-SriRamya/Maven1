package com.cg.spring.SpringBootDemo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.SpringBootDemo.entity.Country;


@Repository
public class CountryDaoImpl implements ICountryDao {

	@Override
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return CountryDb.getCountryList();
	}
	

}
