package com.cg.spring.SpringBootDemo.service;

import java.util.List;

import com.cg.spring.SpringBootDemo.entity.Country;

public interface ICountryService {
	
	public List<Country> getAllCountries();

}
