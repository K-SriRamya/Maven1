package com.cg.spring.SpringBootDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.SpringBootDemo.entity.Country;
import com.cg.spring.SpringBootDemo.service.ICountryService;

@RestController
public class CountryController {
	@Autowired
	ICountryService service;
	
	@RequestMapping(value="/countries",method=RequestMethod.GET,headers="Accept=application/json")
	
	public List<Country> getAllCountries(Model model){
		return service.getAllCountries();
		
	}

}
