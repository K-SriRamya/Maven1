package com.cg.spring.SpringBootDemo.dao;

import java.util.List;

import com.cg.spring.SpringBootDemo.entity.Country;

public interface ICountryDao {
	public List<Country> getAllCountries();

}
